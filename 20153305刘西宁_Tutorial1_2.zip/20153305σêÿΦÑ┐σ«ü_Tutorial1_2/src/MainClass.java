

/**
 * 
 */
public class MainClass {

    /**
     * Default constructor
     */
    public MainClass() {
    }
    
    public static void main(String[] args) {
		LoginForm lf = new LoginForm();
		lf.init();
		lf.display();
		//lf.validate();
	}

}