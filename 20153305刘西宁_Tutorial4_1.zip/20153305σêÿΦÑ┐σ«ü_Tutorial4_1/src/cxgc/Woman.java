package cxgc;

import java.util.*;

/**
 * 
 */
public interface Woman {
	void show();
}