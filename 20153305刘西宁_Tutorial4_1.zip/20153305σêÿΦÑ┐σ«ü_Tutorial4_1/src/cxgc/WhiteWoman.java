package cxgc;

import java.util.*;

/**
 * 
 */
public class WhiteWoman implements Woman {

    /**
     * Default constructor
     */
    public WhiteWoman() {
    }

	@Override
	public void show() {
		System.out.println("白种人 女");
	}

}