package cxgc;

import java.util.*;

/**
 * 
 */
public class YellowWoman implements Woman {

    /**
     * Default constructor
     */
    public YellowWoman() {
    }

	@Override
	public void show() {
		System.out.println("黄种人 女");
	}

}