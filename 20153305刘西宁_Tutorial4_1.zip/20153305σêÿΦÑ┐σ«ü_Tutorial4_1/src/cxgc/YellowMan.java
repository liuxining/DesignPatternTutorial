package cxgc;

import java.util.*;

/**
 * 
 */
public class YellowMan implements Man {

    /**
     * Default constructor
     */
    public YellowMan() {
    }

	@Override
	public void show() {
		System.out.println("黄种人 男");
	}

}