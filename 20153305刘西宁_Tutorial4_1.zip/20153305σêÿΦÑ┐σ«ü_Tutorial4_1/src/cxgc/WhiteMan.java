package cxgc;

import java.util.*;

/**
 * 
 */
public class WhiteMan implements Man {

    /**
     * Default constructor
     */
    public WhiteMan() {
    }

	@Override
	public void show() {
		System.out.println("白种人 男");
	}

}