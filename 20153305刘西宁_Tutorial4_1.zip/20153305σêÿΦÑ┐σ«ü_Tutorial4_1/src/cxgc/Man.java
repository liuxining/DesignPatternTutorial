package cxgc;

import java.util.*;

/**
 * 
 */
public interface Man {
	void show();
}