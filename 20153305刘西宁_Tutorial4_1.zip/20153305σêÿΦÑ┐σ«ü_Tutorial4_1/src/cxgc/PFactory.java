package cxgc;

import java.util.*;

/**
 * 
 */
public interface PFactory {

    /**
     * @return
     */
    public Man productMan();

    /**
     * @return
     */
    public Woman productWoman();

}