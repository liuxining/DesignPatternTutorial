package cxgc;

import java.util.*;

/**
 * 
 */
public class BlackMan implements Man {

    /**
     * Default constructor
     */
    public BlackMan() {
    }

	@Override
	public void show() {
		System.out.println("黑种人 男");
	}

}