package cxgc;

import java.util.*;

/**
 * 
 */
public class BlackWoman implements Woman {

    /**
     * Default constructor
     */
    public BlackWoman() {
    }

	@Override
	public void show() {
		System.out.println("黑种人 女");
	}

}