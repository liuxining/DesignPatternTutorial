
public class RealHunJieSuo implements IHunJieSuo {

	@Override
	public void findObj() {
		System.out.println("正在帮你找对象。。。");
		
	}

}
