
public interface IHunJieSuo {
	void findObj();
}
