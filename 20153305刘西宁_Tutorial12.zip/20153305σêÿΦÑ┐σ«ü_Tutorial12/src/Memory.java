
public class Memory {
	public void check() {
		System.out.println("内存自检");
	}
}
