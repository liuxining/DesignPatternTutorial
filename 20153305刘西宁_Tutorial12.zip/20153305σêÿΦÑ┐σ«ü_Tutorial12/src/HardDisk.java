
public class HardDisk {
	public void read(){
		System.out.println("硬盘读数据");
	}
}
