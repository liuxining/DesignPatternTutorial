
public class Client {
	public static void main(String[] args) {
		MainFrame m = new MainFrame();
		m.on();
	}
}
