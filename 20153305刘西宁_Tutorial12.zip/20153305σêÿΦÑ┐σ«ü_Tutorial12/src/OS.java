
public class OS {
	public void load() {
		System.out.println("OS载入");
	}
}
