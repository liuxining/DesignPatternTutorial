
public interface HLFlyWeight {
	void show(String color);
}
