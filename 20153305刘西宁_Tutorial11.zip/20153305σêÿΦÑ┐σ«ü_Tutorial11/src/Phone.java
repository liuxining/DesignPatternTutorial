
public interface Phone {
	void cell();
}
