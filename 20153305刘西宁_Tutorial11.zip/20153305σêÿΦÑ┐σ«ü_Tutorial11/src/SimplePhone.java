
public class SimplePhone implements Phone {

	@Override
	public void cell() {
		System.out.println("响铃");
	}

}
