
import java.util.*;

/**
 * 
 */
public class Red implements Color {

    /**
     * Default constructor
     */
    public Red() {
    }


    /**
     * @param penType 
     * @param name 
     * @return
     */
    public void bepaint(String penType, String name) {
    	System.out.println(penType + "红色的" + name + ".");
    }

}