
import java.util.*;

/**
 * 
 */
public interface Color {


    /**
     * @param penType 
     * @param name 
     * @return
     */
    public void bepaint(String penType, String name);

}