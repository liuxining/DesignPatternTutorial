
import java.util.*;

/**
 * 
 */
public class Green implements Color {

    /**
     * Default constructor
     */
    public Green() {
    }


    /**
     * @param penType 
     * @param name 
     * @return
     */
    public void bepaint(String penType, String name) {
    	System.out.println(penType + "绿色的" + name + ".");
    }

}