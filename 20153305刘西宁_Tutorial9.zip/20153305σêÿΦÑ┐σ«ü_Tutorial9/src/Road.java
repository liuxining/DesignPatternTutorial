
public interface Road {
	void toRun(String type);
}
