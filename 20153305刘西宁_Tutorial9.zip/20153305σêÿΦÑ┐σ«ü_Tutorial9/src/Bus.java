
public class Bus extends ACar {

	@Override
	public void run() {
		String type = "公共汽车";
		road.toRun(type);
	}

}
