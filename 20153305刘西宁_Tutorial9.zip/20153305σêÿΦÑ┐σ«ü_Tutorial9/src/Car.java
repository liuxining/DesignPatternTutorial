
public class Car extends ACar {

	@Override
	public void run() {
		String type = "小汽车";
		road.toRun(type);
		
	}

}
