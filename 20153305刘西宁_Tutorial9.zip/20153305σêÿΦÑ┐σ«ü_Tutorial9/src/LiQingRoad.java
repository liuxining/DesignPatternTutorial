
public class LiQingRoad implements Road {

	@Override
	public void toRun(String type) {
		System.out.println(type + "正在沥青路上跑");
		
	}

}
