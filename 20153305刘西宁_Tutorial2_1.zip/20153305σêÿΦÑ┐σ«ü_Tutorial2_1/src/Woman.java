
import java.util.*;

/**
 * 
 */
public class Woman implements People {

    /**
     * Default constructor
     */
    public Woman() {
    }

	@Override
	public void show() {
		System.out.println("Woman");
	}

}