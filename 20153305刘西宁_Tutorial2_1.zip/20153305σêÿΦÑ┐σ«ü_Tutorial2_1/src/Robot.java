
import java.util.*;

/**
 * 
 */
public class Robot implements People {

    /**
     * Default constructor
     */
    public Robot() {
    }

	@Override
	public void show() {
		System.out.println("Robot");
	}

}