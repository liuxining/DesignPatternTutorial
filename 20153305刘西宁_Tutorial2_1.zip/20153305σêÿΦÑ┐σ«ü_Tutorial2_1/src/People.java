
import java.util.*;

/**
 * 
 */
public interface People {
	void show();
}