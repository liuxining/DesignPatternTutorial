
import java.util.*;

/**
 * 
 */
public class Man implements People {

    /**
     * Default constructor
     */
    public Man() {
    }

	@Override
	public void show() {
		System.out.println("Man");
		
	}

}