
import java.util.*;

/**
 * 
 */
public interface Factory {

    /**
     * @return
     */
    public Encipherment createEncipherment();

}