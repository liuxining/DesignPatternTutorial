
public interface IDog {
	void dogTalk();
	void dark();
}
