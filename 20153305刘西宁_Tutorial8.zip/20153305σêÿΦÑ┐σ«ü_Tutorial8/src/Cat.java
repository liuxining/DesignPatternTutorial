
public class Cat implements ICat {

	@Override
	public void catTalk() {
		System.out.println("我是一只猫，喵~~~~~");
		
	}

	@Override
	public void zhuo() {
		System.out.println("我是一只猫，我在抓老鼠。。。。。。");
	}

}
