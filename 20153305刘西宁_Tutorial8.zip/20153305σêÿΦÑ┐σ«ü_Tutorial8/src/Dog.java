
public class Dog implements IDog {

	@Override
	public void dogTalk() {
		System.out.println("我是一只狗，汪~~~~~~");
		
	}

	@Override
	public void dark() {
		System.out.println("我是一只狗，我在叫。。。。。。");
		
	}

}
