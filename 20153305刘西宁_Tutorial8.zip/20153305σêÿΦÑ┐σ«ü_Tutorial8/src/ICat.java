
public interface ICat {
	void catTalk();
	void zhuo();
}
